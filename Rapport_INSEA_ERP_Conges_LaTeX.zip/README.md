# Rapport technique INSEA ERP Congés

Le fichier principal est **rapport.tex**. Le PDF compilé est fourni dans l’archive. Le dossier **figures/** contient les captures recadrées de la recette, les diagrammes UML vectoriels et leurs sources Graphviz modifiables.

## Compilation

- **Overleaf**. Importer le ZIP comme nouveau projet. Sélectionner **rapport.tex** comme document principal et **pdfLaTeX** comme compilateur.
- **Localement**. Extraire l’archive, ouvrir le dossier du projet, puis exécuter :

  ```bash
  latexmk -pdf rapport.tex
  ```

  Deux compilations successives avec `pdflatex rapport.tex` conviennent également et permettent de mettre à jour le sommaire.

Graphviz est facultatif. Les diagrammes compilés sont inclus. Après modification d’un fichier `.dot`, exécuter par exemple `dot -Tpdf figures/etats.dot -o figures/etats.pdf`, puis recompiler le rapport.
